        <div class="slider">
<div id="amazingslider-wrapper-1" style="display:block;max-width:100%;height:100%;margin:0px auto 0px;">
        <div id="amazingslider-1" style="display:block;margin:0 auto;">
            <ul class="amazingslider-slides" style="display:none;">
                <li><img src="images/essay.jpg" alt="جشواره ی نوجوان خوارزمی"  title="جشواره ی نوجوان خوارزمی" />
                </li>
                <li><img src="images/shora.jpg" alt="شورای دانش آموزی"  title="شورای دانش آموزی" />
                </li>
            </ul>
            <ul class="amazingslider-thumbnails" style="display:none;">
                <li><img src="images/essay-tn.jpg" alt="جشواره ی نوجوان خوارزمی" title="جشواره ی نوجوان خوارزمی" /></li>
                <li><img src="images/shora-tn.jpg" alt="شورای دانش آموزی" title="شورای دانش آموزی" /></li>
            </ul>
        </div>
    </div>
        </div>