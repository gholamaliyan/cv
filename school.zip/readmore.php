<html>
<head>
    <meta charset="utf-8">
     <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" type="text/css" href="style/styless.css" media="only screen and (min-width:1024px)">
<link rel="stylesheet" media="only screen and (min-width: 200px) and (max-width: 1023px)" href="style/mobilestyles.css">
<script src="sliderengine/jquery.js"></script>
    <script src="sliderengine/amazingslider.js"></script>
    <link rel="stylesheet" type="text/css" href="sliderengine/amazingslider-1.css">
    <script src="sliderengine/initslider-1.js"></script>
    </head>
    <body>
        <!--start top menu-->
<?php include("include/menu-top.php"); ?>
        <!--end top menu-->
        <!--start last news-->
<?php include("include/last-post.php"); ?>
        <!--end last news-->
        <!--start slider-->

        <!--end slider-->
<!--start sidebar-->
<?php include('include/readmore.php'); ?>
<?php include('include/sidebarr.php'); ?>

        <!--end sidebar-->
<!--start content-->

        <!--end content-->
        <!--start menu botton-->
<?php include('include/menu-botton.php'); ?>
        <!--end menu botton-->
 <?php include('include/follow.php'); ?>
        <!--start copyright-->
<?php include('include/copyright.php'); ?>
        <!--end copyright-->
    </body>
</html>